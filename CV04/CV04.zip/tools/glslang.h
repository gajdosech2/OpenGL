#include "GL/glew.h"

GLuint createShaderProgram(char *vertex, char *fragment);
char *textFileRead(char *fn) ;