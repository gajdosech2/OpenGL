#include <iostream>
#include <stdlib.h>
#include "GL/glew.c"
#include "GL/glut.h"
#include "tools/glslang.cpp"

#define PI 3.14159265

GLuint p;  //shader program

GLuint vao, color_tex, fb, depth_rb; 

float angle = 0.0f;  //rotation angle

GLfloat       frame;


void setVertexArray(){

	// Data for a set of triangles
	float points[] = {
	-0.5f, -0.5f,  0.0f,
	0.5f, 0.0f,  0.0f,
	0.0f, 0.5f,  0.0f};

	float normals[] = {
	0.0f, 0.0f,  1.0f,
	0.0f, 0.0f,  1.0f,
	0.0f, 0.0f,  1.0f};

	// vertex buffer objects 
	GLuint points_vbo = 0;
	glGenBuffers (1, &points_vbo);
	glBindBuffer (GL_ARRAY_BUFFER, points_vbo);
	glBufferData (GL_ARRAY_BUFFER, 9 * sizeof (float), points, GL_STATIC_DRAW);

	GLuint normals_vbo = 0;
	glGenBuffers (1, &normals_vbo);
	glBindBuffer (GL_ARRAY_BUFFER, normals_vbo);
	glBufferData (GL_ARRAY_BUFFER, 9 * sizeof (float), normals, GL_STATIC_DRAW);

	glEnable(GL_DEPTH_TEST);

	//Vertex Array Object
	glGenVertexArrays (1, &vao);
	glBindVertexArray (vao);
	glEnableVertexAttribArray (0);
	glBindBuffer (GL_ARRAY_BUFFER, points_vbo);
	glVertexAttribPointer (0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
	glEnableVertexAttribArray (1);
	glBindBuffer (GL_ARRAY_BUFFER, normals_vbo);
	glVertexAttribPointer (1, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	
}

void setFBO(int x, int y){

   glGenTextures(1, &color_tex);
   glBindTexture(GL_TEXTURE_2D, color_tex);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   //NULL means reserve texture memory, but texels are undefined
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, x, y, 0, GL_BGRA, GL_UNSIGNED_BYTE, NULL);
   //-------------------------
   glGenFramebuffersEXT(1, &fb);
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fb);
   //Attach 2D texture to this FBO
   glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, color_tex, 0);
   //-------------------------
   glGenRenderbuffersEXT(1, &depth_rb);
   glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, depth_rb);
   glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT24, x, y);
   //-------------------------
   //Attach depth buffer to FBO
   glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, GL_RENDERBUFFER_EXT, depth_rb);

}

void renderScene(void) {

	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fb);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	glUseProgram(p);

	

	int loc = glGetUniformLocation(p, "angle"); //set rotation angle
	glUniform1f(loc, angle);



	//This is the location of the pass_number uniform variable in our program
	int pass_loc = glGetUniformLocation(p, "pass_number");
	glUniform1i(pass_loc, 1);



	glBindVertexArray (vao);
	// draw points 0-3 from the currently bound VAO with current in-use shader
	glDrawArrays (GL_TRIANGLES, 0, 3);

	
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	

	angle += 0.25f;



	//glUseProgram(0);

	glBindTexture(GL_TEXTURE_2D, color_tex);

	glEnable(GL_TEXTURE_2D);

	
	glUniform1i(pass_loc, 2);

	// draw points 0-3 from the currently bound VAO with current in-use shader
	glDrawArrays (GL_TRIANGLES, 0, 3);



	/*
	glBegin( GL_QUADS );
	glTexCoord2f( 0.0f, 0.0f ); 
	glVertex3f( -1.0f, -1.0f, 0.0f );
	glTexCoord2f( 1.0f, 0.0f ); 
	glVertex3f( 1.0f, -1.0f, 0.0f );
	glTexCoord2f( 1.0f, 1.0f ); 
	glVertex3f( 1.0f, 1.0f, 0.0f );	
	glTexCoord2f( 0.0f, 1.0f ); 
	glVertex3f( -1.0f, 1.0f, 0.0f );	
	glEnd( );
	*/


    glutSwapBuffers();
}

int main(int argc, char **argv) {

	// init GLUT and create Window
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(320,320);
	glutCreateWindow("OpenGL");

	// init GLEW to support extensions
	glewInit();
	if (glewIsSupported("GL_VERSION_3_3"))
        printf("Ready for OpenGL 3.3\n");
    else {
        printf("OpenGL 3.3 not supported\n");
        exit(1);
    }

	p = createShaderProgram("./shaders/shader.vert", "./shaders/shader2.geom","./shaders/shader.frag");

	glUseProgram(p);



	//This is the location of the L_pos uniform variable in our program
	int loc = glGetUniformLocation(p, "L_pos");
	glUniform3f(loc, 0.0, 0.0, 10.0);

	//This is the location of the L_pos uniform variable in our program
	loc = glGetUniformLocation(p, "diffuse_col");
	glUniform4f(loc, 1.0, 1.0, 0.0, 1.0);

	
	float c = cos(0.1*PI/180.0);
	float s = sin(0.1*PI/180.0);

	// set matrix with an array
	float m1[] = {c*c, -s, c*s, 0, 
				  c*s, c, s*s, 0, 
				   -s, 0, c, 0, 
					0, 0, 0, 1};
	float m2[] = {c*c, -s, c*s, 
				  c*s, c, s*s,
				  -s, 0, c};


	//This is the location of the rotation4 uniform variable in our program
	loc = glGetUniformLocation(p, "rotation4");
	glUniformMatrix4fv(loc, 1, GL_FALSE,  m1);

	//This is the location of the rotation3 uniform variable in our program
	loc = glGetUniformLocation(p, "rotation3");
	glUniformMatrix3fv(loc, 1, GL_FALSE,  m2);


	//0 is the texture unit where I want to bind my texture
	loc = glGetUniformLocationARB(p, "tex");
	glUniform1iARB(loc, 0);




	setVertexArray();

	setFBO(320, 320);

	// register callbacks
	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene);

	// enter GLUT event processing cycle
	glutMainLoop();
	
	return 1;
}