#include "GL/glew.h"

GLuint createShaderProgram(const char *vertex, const char *fragment);
char *textFileRead(const char *fn) ;